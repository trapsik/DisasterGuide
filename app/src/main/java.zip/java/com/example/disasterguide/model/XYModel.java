package com.example.disasterguide.model;

public class XYModel {
    public double x;
    public double y;

    public XYModel() {}

    public XYModel(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
